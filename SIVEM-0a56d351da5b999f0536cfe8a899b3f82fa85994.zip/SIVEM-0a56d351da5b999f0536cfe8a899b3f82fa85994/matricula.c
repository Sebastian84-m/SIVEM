#include <stdio.h>
#include "registro.h"
#include "matricula.h"
#include "limpiar.h"


// Usa variables globales definidas externamente
extern struct Vehiculo lista[];   // Arreglo global de vehiculos
extern int total;                 // Numero de vehiculos registrados


