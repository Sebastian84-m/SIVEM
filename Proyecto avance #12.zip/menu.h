#ifndef MENU_H
#define MENU_H

void mostrarMenu();
void procesarOpcion(int opcion);

#endif
