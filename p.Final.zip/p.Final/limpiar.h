#ifndef LIMPIAR_H
#define LIMPIAR_H
#include <windows.h>

// Funci�n para limpiar la pantalla de la terminal
void limpiar_pantalla();

// Funci�n para limpiar el buffer de entrada
void limpiar_buffer();

void esperar_3segundos();
#endif
