#ifndef LOGIN_H
#define LOGIN_H

// Funci�n para iniciar sesi�n
int login();

// Funci�n para registrar nuevo usuario
void registrarUsuario();

#endif
