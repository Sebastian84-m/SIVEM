#include <stdio.h>
#include "registro.h"
#include "revision.h"

extern struct Vehiculo lista[];
extern int total;

void registrarRevision() {
	if (total == 0) {
		printf("\nNo hay vehiculos registrados.\n");
		return;
	}
	
	char placa[10];
	printf("\n--- Registrar Revision ---\n");
	printf("Ingrese placa del vehiculo (ABC-1234): ");
	scanf("%9s", placa);
	
	int encontrado = 0;
	for (int i = 0; i < total; i++) {
		if (strcmp(lista[i].placa, placa) == 0) {
			printf("\nVehiculo encontrado:\n");
			mostrarResumen(lista[i]);
			printf("Revision registrada exitosamente.\n");
			encontrado = 1;
			break;
		}
	}
	
	if (!encontrado) {
		printf("\nVehiculo con placa %s no encontrado.\n", placa);
	}
}
void listaVehiculos(){
	if (total == 0) {
		printf("\nNo hay vehiculos registrados.\n");
		return; // Sale de la funci�n si la lista est� vac�a
	}
	
	printf("\n===== Vehiculos Registrados =====\n");
	for (int i = 0; i < total; i++) {  //Recorre todos los veh�culos registrados para procesarlos uno a uno.
		printf("Vehiculo: %d\n", i + 1);
		printf("Cedula %s\n",lista[i].cedula);
		printf("Placa: %s\n", lista[i].placa);
		printf("A�o: %d\n",lista[i].anio);
		printf("Tipo: %s\n", lista[i].tipo);
		printf("Revisiones Tecnicas: %d\n", lista[i].revisiones);
		printf("Modelo: %s\n", lista[i].modelo);
		printf("Avaluo: $%.2f\n", lista[i].avaluo);
		printf("Costo matricula: $%.2f\n\n", lista[i].costo);
		printf("================================================\n");
	}
	char z;
	
	do {
		printf("Desea volver al menu? (S o N): ");
		scanf(" %c", &z);
		limpiarBuffer();
		if (!(z == 'S' || z == 's' || z == 'N' || z == 'n')) {
			printf("Entrada inv�lida. Por favor ingrese solo 'S' o 'N'.\n");
		}
	} while (!(z == 'S' || z == 's' || z == 'N' || z == 'n'));
	
	if (z == 'N' || z == 'n') {
		limpiar_pantalla();
		printf("Gracias por usar.\n");
		exit(0);
	}
	limpiar_pantalla();
	return 0;
}
