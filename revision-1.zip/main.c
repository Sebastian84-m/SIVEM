#include <stdio.h>    // Incluye la librer�a est�ndar de entrada/salida (para printf/scanf)
#include "menu.h"       
#include "registro.h"    
#include "matricula.h"   
#include "revision.h"    
#include "login.h"

//declaramos las funciones
void guardarVehiculos();
void cargarVehiculos();

int main() {
	
	cargarUsuarios();  // Carga los usuarios registrados
	
	int opcion;
	//Se cargan los datos al inicio 
	cargarVehiculos();
	//creamos el bucle de la funcion mostrarMenu
	do {
		limpiar_pantalla();
		
		printf("\n=== SISTEMA DE ACCESO ===\n");
		printf("1. Iniciar sesion\n");
		printf("2. Registrar nuevo usuario\n");
		printf("3. Salir\n");
		printf("Seleccione opcion: ");
		
		if(scanf("%d", &opcion) != 1) {
			printf("\nEntrada invalida. Debe colocar una opcion valida.\n");
			limpiar_buffer();
			esperar_3segundos();  // Espera 3 segundos
			continue;
		}
		
		switch(opcion) {
		case 1:
			if (login()) {  // Si el login es exitoso entoncea
				int opcionMenu;
				do {
					mostrarMenu();
					if(scanf("%d", &opcionMenu) != 1) {
						printf("Entrada invalida. Debe colocar una de las 4 opciones.\n");
						while(getchar() != '\n');
						continue;
					}
					procesarOpcion(opcionMenu);
					
					if (opcionMenu == 1) {  
						guardarVehiculos();
					}
				} while(opcionMenu != 4);
			}
			break;
		case 2:
			registrarUsuario();
			break;
		case 3:
			printf("\nSaliendo del programa.\n");
			break;
		default:
			printf("\nOpcion no valida. Intente de nuevo.\n");
		}
	} while(opcion != 3);
	return 0;
}
