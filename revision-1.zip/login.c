#include <stdio.h>
#include <string.h>
#include "login.h"
#include "limpiar.h"

#define MAX_USUARIOS 10
#define MAX_LONGITUD 20

struct Usuario {
	char nombre[MAX_LONGITUD];
	char contrasena[MAX_LONGITUD];
};

struct Usuario usuarios[MAX_USUARIOS];
int totalUsuarios = 0;

// Cargar usuarios desde archivo al iniciar
void cargarUsuarios() {
	FILE *archivo = fopen("usuarios.txt", "r");
	if (archivo == NULL) return;
	
	while (fscanf(archivo, "%19s %19s", usuarios[totalUsuarios].nombre, usuarios[totalUsuarios].contrasena) == 2) {
		totalUsuarios++;
		if (totalUsuarios >= MAX_USUARIOS) break;
	}
	fclose(archivo);
}

// Guardar usuarios en archivo
void guardarUsuarios() {
	FILE *archivo = fopen("usuarios.txt", "w");
	if (archivo == NULL) return;
	
	for (int i = 0; i < totalUsuarios; i++) {
		fprintf(archivo, "%s %s\n", usuarios[i].nombre, usuarios[i].contrasena);
	}
	fclose(archivo);
}

// Funci�n para registrar nuevo usuario
void registrarUsuario() {
	if (totalUsuarios >= MAX_USUARIOS) {
		printf("�M�ximo de usuarios alcanzado!\n");
		return;
	}
	
	printf("\n--- Registro de Nuevo Usuario ---\n");
	printf("Nombre de usuario: ");
	if(scanf("%19s", usuarios[totalUsuarios].nombre) != 1) {
		limpiar_buffer();
		return;
	}
	limpiar_buffer();
	
	printf("Contrase�a: ");
	if(scanf("%19s", usuarios[totalUsuarios].contrasena) != 1) {
		limpiar_buffer();
		return;
	}
	limpiar_buffer();
	
	totalUsuarios++;
	guardarUsuarios();
	printf("�Usuario registrado con �xito!\n");
}

// Funci�n para iniciar sesi�n
int login() {
	limpiar_pantalla();
	char nombre[MAX_LONGITUD];
	char contrasena[MAX_LONGITUD];
	
	printf("\n--- Inicio de Sesi�n ---\n");
	printf("Usuario: ");
	if(scanf("%19s", nombre) != 1) {
		limpiar_buffer();
		printf("\nError en entrada de usuario\n");
		esperar_3segundos();
		return 0;
	}
	limpiar_buffer();
	
	printf("Contrase�a: ");
	if(scanf("%19s", contrasena) != 1) {
		limpiar_buffer();
		printf("\nError en entrada de contrase�a\n");
		esperar_3segundos();
		return 0;
	}
	limpiar_buffer();
	
	// Verificar credenciales
	for (int i = 0; i < totalUsuarios; i++) {
		if (strcmp(nombre, usuarios[i].nombre) == 0 && strcmp(contrasena, usuarios[i].contrasena) == 0) {
			printf("�Bienvenido, %s!\n", nombre);
			esperar_3segundos();
			limpiar_pantalla();
			return 1; // Login exitoso
		}
	}
	
	// Si las credenciales son incorrectas
	printf("\nUsuario o contrase�a incorrectos.\n");
	esperar_3segundos();
	return 0; // Login fallido
}
