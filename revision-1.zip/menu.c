#include <stdio.h>
#include "menu.h"
#include "registro.h"
#include "matricula.h"
#include "revision.h"
#include "limpiar.h"

//declaramos la funcion mostrarMenu

void mostrarMenu() {
	printf("\n=== SISTEMA SIVEM ===\n");
	printf("1. Registrar vehiculo\n");
	printf("2. Buscar vehiculo\n");
	printf("3. Lista de vehiculos\n");
	printf("4. Salir\n");
	printf("Seleccione opcion: ");
}

//Declaramos la funcion procesarOpcion


void procesarOpcion(int opcion) {    //recibe una opcion num�rica
		switch(opcion) { //evaluar el valor de la opcion
	case 1:
		limpiar_pantalla(); 
		registrarVehiculo();
		break;
	case 2:
		limpiar_pantalla();
		buscarVehiculoPorPlaca();
		break;
	case 3:
		limpiar_pantalla();
		listaVehiculos();
		break;
	case 4:
		printf("\nSaliendo del programa.\n");
		break;
	default:
		limpiar_pantalla();
		printf("\nOpcion no valida.Ingrese otra opcion.\n");
	}
}
